# Devices

## Endpoints
- [List devices](#list-devices)
- [Get device history for an account](#get-device-history-for-an-account)
- [Get device history](#get-device-history)
- [Get device](#get-device)
- [Create device](#create-device)
- [Update device](#update-device)
- [Delete device](#delete-device)

Registered hardware devices available to the authenticated account.

**Clearance requirements:** create requires clearance level 2 or lower, read requires clearance level 5 or lower, update requires clearance level 2 or lower and delete requires clearance level 2 or lower.

## List devices

Retrieve every device visible to the authenticated account, optionally filtering by inventory, model, operational status or a custom identifier.

Clearance level 5 or lower is required to read devices through this endpoint.

### Endpoint
```
GET /devices
```

### Headers

| Header | Required | Description | Type |
| --- | --- | --- | --- |
| `Authorization` | Yes | API key generated from your profile | string |
| `Account` | Yes | Target account ID | int |

### Query parameters

| Parameter | Required | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `skip` | No | int | `0` | Pagination offset. |
| `limit` | No | int | `100` | Maximum number of records to return. |
| `id_inventory` | No | int | No | Filter devices associated with a specific inventory returned by [List inventories](../Setups/inventories.md#list-inventories). |
| `id_device_model` | No | int | No | Filter devices by the related model identifier returned by [List device models](./device_models.md#list-device-models). |
| `id_device_status` | No | int | No | Filter devices by their operational status identifier (`1` for connected, `2` for disconnected). |
| `device_custom_id` | No | string | No | Filter devices by the account-specific custom identifier. |
| `updated_at_from` | No | int | No | Inclusive UNIX timestamp in seconds for an incremental read. |
| `cursor` | No | string | No | Opaque cursor from the `X-Next-Updated-At-Cursor` response header. |

### Incremental reads

Use `updated_at_from` on the first request of a synchronization window. The
service captures the current UTC second as the upper bound, compares
`updated_at` with a `created_at` fallback, and orders incremental results by
the effective timestamp and `id_device` in ascending order. If another page
exists, the response includes `X-Next-Updated-At-Cursor`; send that opaque
value as `cursor` on the next request with `skip=0`.

`updated_at_from` and `cursor` are mutually exclusive. A non-zero `skip` with
a cursor returns `400`. Without either parameter, the normal offset pagination
and collection ordering are unchanged. Incremental device reads contain
current account-visible devices only and do not emit deletion tombstones; use
an event-history or reconciliation flow to detect removals.

### Sample headers
```json
{
  "Authorization": "<API_KEY>",
  "Account": "<ID_ACCOUNT>"
}
```

### Sample request
```bash
curl -H "Authorization: <API_KEY>" \
  -H "Account: <ID_ACCOUNT>" \
  "/devices?limit=20&device_custom_id=NODE-01&updated_at_from=1788307200"
```

If the response contains another page, continue with:

```http
X-Next-Updated-At-Cursor: <opaque-cursor>
```

### Sample response (200)
```json
{
  "status": "success",
  "message": "Devices retrieved successfully",
  "data": [
    {
      "id_device": 1,
      "id_location": 500010,
      "id_inventory": 8,
      "id_device_model": 3,
      "id_device_status": 2,
      "device_custom_id": "NODE-01",
      "device_ip": "192.0.2.101",
      "device_observations": "Outdoor gateway",
      "device_configuration": null,
      "device_archived": false,
      "device_status_since": "2024-03-17T15:24:51Z"
    },
    {
      "id_device": 2,
      "id_location": null,
      "id_inventory": null,
      "id_device_model": 5,
      "id_device_status": 1,
      "device_custom_id": "NODE-02",
      "device_ip": null,
      "device_observations": null,
      "device_configuration": "{}",
      "device_archived": false,
      "device_status_since": null
    }
  ],
  "context": {},
  "instance": "/devices"
}
```

### Response data attributes

| Field | Type | Description |
| --- | --- | --- |
| `id_device` | int | Numeric identifier of the device. Use [Get device](#get-device) to retrieve its details. |
| `id_location` | int | Location identifier assigned to the device. |
| `id_inventory` | int | Inventory identifier where the device is located. |
| `id_device_model` | int | Identifier of the device model that defines the capabilities of the hardware. |
| `id_device_status` | int | Identifier representing the device operational status (`1` is connected, `2` is disconnected). |
| `device_custom_id` | string | Account-specific identifier assigned to the device. |
| `device_ip` | string | Device IP address, when available; supports IPv4 or IPv6 values up to 45 characters. |
| `device_observations` | string | Free-form notes about the device. |
| `device_configuration` | string | Serialized configuration applied to the device. |
| `device_archived` | bool | Indicates whether the device is archived. |
| `device_status_since` | string | ISO-8601 timestamp for the last status change. |

### Status codes

| Status | Description |
| --- | --- |
| `200` | Devices retrieved successfully. |
| `400` | Pagination or filter validation failed. |
| `401` | Authentication failed. |
| `403` | The authenticated user is not authorized to list devices. |
| `404` | Not used for this collection endpoint. |
| `500` | Unexpected server error. |

### Error response (403)
```json
{
  "status": "error",
  "message": "Insufficient permissions",
  "data": null,
  "context": {
    "headers": {
      "Account": "<ID_ACCOUNT>"
    }
  },
  "instance": "/devices"
}
```

## Get device history for an account

Retrieve status changes for several devices in one account-scoped request. When
`id_device` is omitted, the endpoint covers every visible device; repeat the
parameter to restrict the result to a selected set. This avoids one HTTP call
per device for historical exports.

Clearance 5 is required to use this endpoint.

### Endpoint
```
GET /devices/history
```

### Headers

| Header | Required | Description | Type |
| --- | --- | --- | --- |
| `Authorization` | Yes | API key generated from your profile | string |
| `Account` | Yes | Target account ID | int |

### Query parameters

| Parameter | Required | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `from` | No | int | `now - 7 days` | Inclusive UNIX timestamp for the beginning of the window. |
| `to` | No | int | `now` | Inclusive UNIX timestamp for the end of the window. |
| `id_device` | No | int, repeatable | All visible devices | Restrict results to one or more device identifiers. |
| `skip` | No | int | `0` | Pagination offset across the combined result. |
| `limit` | No | int | `100` | Maximum number of events; capped at `500`. |

`from` and `to` use the same inclusive UNIX-second semantics as the individual
history endpoint. An explicitly inverted range returns `400`. Results are
ordered newest first with a deterministic event-id tie breaker.

### Sample request
```bash
curl -H "Authorization: <API_KEY>" \
  -H "Account: <ID_ACCOUNT>" \
  "/devices/history?from=1711929600&to=1712016000&id_device=500010&id_device=500011&limit=100"
```

### Sample response (200)
```json
{
  "status": "success",
  "message": "Elements obtained successfully",
  "data": [
    {
      "id_event": 6050,
      "id_device": 500010,
      "status_change_timestamp": "2024-04-01T09:15:00Z",
      "id_device_status": 1
    },
    {
      "id_event": 6049,
      "id_device": 500011,
      "status_change_timestamp": "2024-04-01T09:10:00Z",
      "id_device_status": 2
    }
  ],
  "context": {},
  "instance": "/devices/history"
}
```

### Status codes

| Status | Description |
| --- | --- |
| `200` | History retrieved successfully. |
| `400` | Date range, device filter, or pagination validation failed. |
| `401` | Authentication failed. |
| `403` | The authenticated user is not authorized to read device history. |
| `500` | Unexpected server error. |

## Get device history

Retrieve status change events for a single device. The device identifier must belong to the account provided in the `Account` header.

Clearance 5 is required to use this endpoint.

### Endpoint
```
GET /devices/{id_device}/history
```

### Headers

| Header | Required | Description | Type |
| --- | --- | --- | --- |
| `Authorization` | Yes | API key generated from your profile | string |
| `Account` | Yes | Target account ID | int |

### Path parameters

| Parameter | Required | Type | Description |
| --- | --- | --- | --- |
| `id_device` | Yes | int | Device identifier returned by [List devices](#list-devices). |

### Query parameters

| Parameter | Required | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `from` | No | int | `now - 7 days` | UNIX timestamp in seconds for the start of the time window (inclusive). |
| `to` | No | int | `now` | UNIX timestamp in seconds for the end of the time window (inclusive). |
| `skip` | No | int | `0` | Pagination offset. |
| `limit` | No | int | `100` | Maximum number of events to return. |

`from` and `to` are inclusive UNIX-second boundaries. If either boundary is
omitted, the API derives it from the seven-day default window. An explicitly
inverted range (`from > to`) returns `400`; the API does not swap the values.

### Sample request
```bash
curl -H "Authorization: <API_KEY>" \
  -H "Account: <ID_ACCOUNT>" \
  "/devices/500010/history?from=1711929600&to=1712016000&skip=0&limit=20"
```

### Sample response (200)
```json
{
  "status": "success",
  "message": "Elements obtained successfully",
  "data": [
    {
      "id_event": 6050,
      "id_device": 500010,
      "status_change_timestamp": "2024-04-01T09:15:00Z",
      "id_device_status": 1
    },
    {
      "id_event": 6042,
      "id_device": 500010,
      "status_change_timestamp": "2024-03-31T23:05:00Z",
      "id_device_status": 2
    }
  ],
  "context": {},
  "instance": "/devices/500010/history"
}
```

## Get device

Retrieve a device by its numeric identifier.

Clearance level 5 or lower is required to read devices through this endpoint.

### Endpoint
```
GET /devices/{id_device}
```

### Headers

| Header | Required | Description | Type |
| --- | --- | --- | --- |
| `Authorization` | Yes | API key generated from your profile | string |
| `Account` | Yes | Target account ID | int |

### Path parameters

| Parameter | Required | Type | Description |
| --- | --- | --- | --- |
| `id_device` | Yes | int | Numeric identifier of the device to retrieve. |

### Query parameters

This endpoint does not accept query parameters.

### Sample headers
```json
{
  "Authorization": "<API_KEY>",
  "Account": "<ID_ACCOUNT>"
}
```

### Sample request
```bash
curl -H "Authorization: <API_KEY>" \
  -H "Account: <ID_ACCOUNT>" \
  /devices/1
```

### Sample response (200)
```json
{
  "status": "success",
  "message": "Element obtained successfully",
  "data": {
    "id_device": 1,
    "id_location": 500010,
    "id_inventory": 8,
    "id_device_model": 3,
    "id_device_status": 2,
    "device_custom_id": "NODE-01",
    "device_ip": "192.0.2.101",
    "device_observations": "Outdoor gateway",
    "device_configuration": null,
    "device_archived": false,
    "device_status_since": "2024-03-17T15:24:51Z"
  },
  "context": {},
  "instance": "/devices/1"
}
```

### Response data attributes

| Field | Type | Description |
| --- | --- | --- |
| `id_device` | int | Numeric identifier of the device. |
| `id_inventory` | int | Inventory identifier where the device is located. |
| `id_device_model` | int | Identifier of the device model that defines the capabilities of the hardware. Use [Get device model](./device_models.md#get-device-model) to retrieve its catalog entry. |
| `id_device_status` | int | Identifier representing the device operational status (`1` is connected, `2` is disconnected). |
| `device_custom_id` | string | Account-specific identifier assigned to the device. |
| `device_ip` | string | Device IP address, when available; supports IPv4 or IPv6 values up to 45 characters. |
| `device_observations` | string | Free-form notes about the device. |
| `device_configuration` | string | Serialized configuration applied to the device. |
| `device_archived` | bool | Indicates whether the device is archived. |
| `device_status_since` | string | ISO-8601 timestamp for the last status change. |

### Status codes

| Status | Description |
| --- | --- |
| `200` | Device retrieved successfully. |
| `400` | Validation failed for the provided identifier. |
| `401` | Authentication failed. |
| `403` | The authenticated user is not authorized to read devices. |
| `404` | Device not found for the supplied identifier. |
| `500` | Unexpected server error. |

### Error response (404)
```json
{
  "status": "error",
  "message": "Device not found",
  "data": null,
  "context": {
    "params": {
      "id_device": 99999
    }
  },
  "instance": "/devices/99999"
}
```

## Create device

Register a new device within the authenticated account.

Clearance level 2 or lower is required to use this endpoint.

### Endpoint
```
POST /devices
```

### Headers

| Header | Required | Description | Type |
| --- | --- | --- | --- |
| `Authorization` | Yes | API key generated from your profile | string |
| `Account` | Yes | Target account ID | int |

### Request body

| Field | Required | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `id_inventory` | No | int | No | Inventory where the device is stored. Retrieve it from [List inventories](../Setups/inventories.md#list-inventories). |
| `id_location` | No | int | No | Reusable location assigned to the device. Obtain it from [List locations](../Global_resources/locations.md#list-locations). |
| `id_device_model` | Yes | int | No | Device model that defines the capabilities of the hardware. Obtain it from [Get device model](./device_models.md#get-device-model). |
| `id_device_status` | No | int | No | Operational status identifier (`1` for connected, `2` for disconnected). |
| `device_custom_id` | No | string | No | Account-specific identifier assigned to the device. |
| `device_observations` | No | string | No | Free-form notes about the device. |
| `device_configuration` | No | string | No | Serialized configuration that should be applied to the device. |
| `device_archived` | No | bool | false | Set to `true` to create the device in an archived state. |

### Sample headers
```json
{
  "Authorization": "<API_KEY>",
  "Account": "<ID_ACCOUNT>"
}
```

### Sample request
```bash
curl -X POST -H "Authorization: <API_KEY>" \
  -H "Account: <ID_ACCOUNT>" \
  -H "Content-Type: application/json" \
  -d '{
    "id_device_model": 3,
    "id_inventory": 8,
    "id_location": 500010,
    "device_custom_id": "NODE-100",
    "device_observations": "Installed in warehouse"
  }' \
  /devices
```

### Sample response (201)
```json
{
  "status": "success",
  "message": "Element created successfully",
  "data": {
    "id_device": 120,
    "id_location": 500010,
    "id_inventory": 8,
    "id_device_model": 3,
    "id_device_status": null,
    "device_custom_id": "NODE-100",
    "device_observations": "Installed in warehouse",
    "device_configuration": null,
    "device_archived": false,
    "device_status_since": null
  },
  "context": {
    "body": {
      "id_device_model": 3,
      "id_inventory": 8,
      "id_location": 500010,
      "device_custom_id": "NODE-100",
      "device_observations": "Installed in warehouse"
    }
  },
  "instance": "/devices"
}
```

### Status codes

| Status | Description |
| --- | --- |
| `201` | Device created successfully. |
| `400` | Validation failed for the provided payload. |
| `401` | Authentication failed. |
| `403` | The authenticated user lacks clearance to create devices. |
| `404` | Referenced inventory or device model was not found. |
| `500` | Unexpected server error. |

### Error response (404)
```json
{
  "status": "error",
  "message": "DeviceModel with id_device_model 999 does not exist",
  "data": null,
  "context": {
    "body": {
      "id_device_model": 999,
      "device_custom_id": "INVALID"
    }
  },
  "instance": "/devices"
}
```

## Update device

Modify an existing device. Omitted fields keep their current value.

Clearance level 2 or lower is required to use this endpoint.

### Endpoint
```
PUT /devices/{id_device}
```

### Headers

| Header | Required | Description | Type |
| --- | --- | --- | --- |
| `Authorization` | Yes | API key generated from your profile | string |
| `Account` | Yes | Target account ID | int |

### Path parameters

| Parameter | Required | Type | Description |
| --- | --- | --- | --- |
| `id_device` | Yes | int | Numeric identifier of the device to update. |

### Request body

| Field | Required | Type | Default | Description |
| --- | --- | --- | --- | --- |
| `id_inventory` | No | int | No | Inventory where the device is stored. |
| `id_location` | No | int | No | Reusable location assigned to the device. |
| `id_device_model` | No | int | No | Device model assigned to the hardware. |
| `id_device_status` | No | int | No | Operational status identifier. |
| `device_custom_id` | No | string | No | Account-specific identifier assigned to the device. |
| `device_ip` | No | string | No | IPv4 or IPv6 address to persist for the device; maximum length is 45 characters. |
| `device_observations` | No | string | No | Updated notes about the device. |
| `device_configuration` | No | string | No | Updated serialized configuration. |
| `device_archived` | No | bool | No | Set to `true` to archive the device. |

### Sample headers
```json
{
  "Authorization": "<API_KEY>",
  "Account": "<ID_ACCOUNT>"
}
```

### Sample request
```bash
curl -X PUT -H "Authorization: <API_KEY>" \
  -H "Account: <ID_ACCOUNT>" \
  -H "Content-Type: application/json" \
  -d '{
    "id_location": 500011,
    "id_inventory": 9,
    "device_ip": "192.0.2.120",
    "device_archived": true
  }' \
  /devices/120
```

### Sample response (200)
```json
{
  "status": "success",
  "message": "Element updated successfully",
  "data": {
    "id_device": 120,
    "id_location": 500011,
    "id_inventory": 9,
    "id_device_model": 3,
    "id_device_status": null,
    "device_custom_id": "NODE-100",
    "device_ip": "192.0.2.120",
    "device_observations": "Installed in warehouse",
    "device_configuration": null,
    "device_archived": true,
    "device_status_since": null
  },
  "context": {
    "body": {
      "id_location": 500011,
      "id_inventory": 9,
      "device_ip": "192.0.2.120",
      "device_archived": true
    },
    "path": {
      "id_device": "120"
    }
  },
  "instance": "/devices/120"
}
```

### Status codes

| Status | Description |
| --- | --- |
| `200` | Device updated successfully. |
| `400` | Validation failed for the provided payload. |
| `401` | Authentication failed. |
| `403` | The authenticated user lacks clearance to update devices. |
| `404` | Device or referenced inventory or model was not found. |
| `500` | Unexpected server error. |

### Error response (404)
```json
{
  "status": "error",
  "message": "Device 120 was not found",
  "data": null,
  "context": {
    "path": {
      "id_device": "120"
    }
  },
  "instance": "/devices/120"
}
```

## Delete device

Remove a device from the authenticated account.

Clearance level 2 or lower is required to use this endpoint.

### Endpoint
```
DELETE /devices/{id_device}
```

### Headers

| Header | Required | Description | Type |
| --- | --- | --- | --- |
| `Authorization` | Yes | API key generated from your profile | string |
| `Account` | Yes | Target account ID | int |

### Path parameters

| Parameter | Required | Type | Description |
| --- | --- | --- | --- |
| `id_device` | Yes | int | Numeric identifier of the device to delete. |

### Sample headers
```json
{
  "Authorization": "<API_KEY>",
  "Account": "<ID_ACCOUNT>"
}
```

### Sample request
```bash
curl -X DELETE -H "Authorization: <API_KEY>" \
  -H "Account: <ID_ACCOUNT>" \
  /devices/120
```

### Sample response (200)
```json
{
  "status": "success",
  "message": "Element removed successfully",
  "data": null,
  "context": {
    "path": {
      "id_device": "120"
    }
  },
  "instance": "/devices/120"
}
```

### Status codes

| Status | Description |
| --- | --- |
| `200` | Device removed successfully. |
| `401` | Authentication failed. |
| `403` | The authenticated user lacks clearance to delete devices. |
| `404` | Device not found for the provided identifier. |
| `500` | Unexpected server error. |

### Error response (404)
```json
{
  "status": "error",
  "message": "Device 120 was not found",
  "data": null,
  "context": {
    "path": {
      "id_device": "120"
    }
  },
  "instance": "/devices/120"
}
```
