# MGD gateway JSON projection

## Endpoint

```http
GET /mgd/gateways/{id_setup}/config-json?projection=proposed
```

`{id_setup}` is the gateway `setups.id_setup`. `projection` accepts:

- `applied`: live canonical rows.
- `proposed`: those same rows plus `after_value` overlays from active MGD
  changes, in creation order: `on_hold`, `pending`, `in_progress`, and
  `retry`.

The response is a read envelope:

```json
{
  "id_setup": 501234,
  "id_setup_gateway": 501234,
  "projection": "proposed",
  "status": "complete",
  "active_change_ids": [901, 902],
  "cancelled_change_ids": [],
  "failed_change_ids": [],
  "unresolved": [],
  "config": {
    "json_version": "v4.1",
    "id": "gateway-1",
    "name": "Gateway 1",
    "database": {},
    "lambda_functions": {}
  }
}
```

`config` keeps the functional shape of `lambda_config.json`: links are
`device_key`, component, type, and schedule number, not internal MGD primary
keys. With eager write those primary keys already exist. If an overlay cannot
rebuild a required relationship, the response remains valid JSON but returns
`status="unresolved"` and explains why in `unresolved`; that document must not
be sent to the physical gateway.

The endpoint is read-only. It does not change `config_changes`, write rows, or
publish SQS. Compensation happens inside the API when the worker or operator
marks `cancelled` or `failed`. Clickie may show the new value while the device
still has the previous one. `include_config_sync=true` on this endpoint
attaches the **gateway** rollup hint. Per-row sync belongs on that resource’s
GET. After a compensated `failed` of a resource, `is_synchronized=true` **for
that row**.

## Device types and reader points

The `device_types` block is generated JSON, not a relational table. A point is
resolved from the `device_model_points` catalog through
`id_device_model_point`, and its exported register key is `point_key`. The
projection must not create a partially populated point when the catalog link
cannot be resolved; it reports the reason in `unresolved` instead.

For a device point, the effective values follow this precedence:

| Output field | Effective value |
| --- | --- |
| `factor` | Device `factor_override`, then model `factor_default`, then `1`. |
| `available_status` on a writable point | Device override, then model `available_status_default`. |
| `available_status` on a read-only point | Omitted. |

The same rule applies to the `device_types` register definition and to
`devices.*.register_groups[].configs`. A model default shown only in
`device_types` is insufficient if the device-level config is emitted without
the effective factor. A `factor_override` of `null` means that the device
inherits the model value; it does not mean that the effective factor is null.

When a reader response contains null `id` or `device_type`, first confirm that
the response came from this AP-v4 projection, that the intended
`projection=applied|proposed` was used, and that the deployed version matches
the public contract. The current projection contract uses a resolvable child
identity and model name, or reports an unresolved reference.

## What `cancelled` means

`cancelled` is terminal: the intent is no longer applicable. A cancelled
proposal is excluded from `projection=proposed`:

| Case | Projection result |
| --- | --- |
| Cancelled create | Compensation deletes the row; the resource is absent. |
| Cancelled update | The previous value is restored. |
| Cancelled delete | The canonical resource is recreated. |
| Cancelled group | All of its cancellable rows are excluded as one logical unit. |

`on_hold`, `pending`, and `retry` can be cancelled. Cancelling `pending`
compensates Clickie; if the worker later attempts an illegal transition, it
receives `409` and terminates. An `in_progress` row is not cancelled from
AP-v4. `applied` is not cancelled: if the physical value must be reverted,
create a new inverse proposal. `failed` is not reopened; create a new proposal
or use the external recovery procedure.

## Identity and keys

These table primary keys are internal integers. An eager create already has
`id_resource`. `id_setup_target` separates the gateway from each child so
scope is not inferred.

| Resource | Table | Canonical REST identity | Main relationships |
| --- | --- | --- | --- |
| Gateway config | `setup_gateway_configs` | `{id_setup}`; `id_setup_gateway_config` in the representation | one gateway, one-to-one |
| Component | `setup_gateway_components` | `{id_setup_gateway_component}` | gateway setup + `id_gateway_component_type` |
| Device config | `setup_gateway_device_configs` | `{config}` under `/devices/{child}/configs` | gateway + component + child setup |
| Device point | `setup_gateway_device_points` | `{id_device_model_point}` under an explicit config | device config + catalog `id_device_model_point`; response also exposes `id_setup_gateway_device_point` |
| Point group | `setup_gateway_point_groups` | `{group}` = `id_setup_gateway_point_group` | device config + optional schedule |
| Schedule | `setup_gateway_schedules` | `{schedule}` = `id_setup_gateway_schedule` | component + schedule type + scope |
| Special day | `setup_gateway_special_days` | `{special_day}` = `id_setup_gateway_special_day` | component |
| Extension | `setup_gateway_extensions` | `{extension}` = `id_setup_gateway_extension` | component + schedules via bridge |
| Point-group point | `setup_gateway_point_group_points` | `{link}` = bridge PK | group + device point |
| Point-group special day | `setup_gateway_point_group_special_days` | `{link}` = bridge PK | group + special day |
| Extension schedule | `setup_gateway_extension_schedules` | `{link}` = bridge PK | extension + schedule |
| Config change | `setup_gateway_config_changes` | `{change}` = `id_setup_gateway_config_change` | gateway + target + entity + resource |

`id_device_model_point` is not the MGD row ID; it is the model catalog
reference used in the nested point route. The response also exposes the MGD
row ID `id_setup_gateway_device_point`. Clients must not substitute one ID for
the other.

## Uniqueness enforced by the database

These constraints are part of the contract and must not be duplicated with
“first row wins” resolvers in the repository:

| Rule | Constraint |
| --- | --- |
| One root config per gateway | `UNIQUE(id_setup_gateway)` |
| One component of each type per setup | `UNIQUE(id_setup, id_gateway_component_type)` |
| One device key per gateway | `UNIQUE(id_setup_gateway, device_key)` |
| One catalog point per device config | `UNIQUE(id_setup_gateway_device_config, id_device_model_point)` |
| One schedule per type/number/scope/component | `UNIQUE(id_setup_gateway_component, id_gateway_schedule_type, schedule_number, schedule_scope_type)` |
| One special-day per component and name | `UNIQUE(id_setup_gateway_component, day_group_name)` |
| One extension per schedule | `UNIQUE(id_setup_gateway_extension, id_setup_gateway_schedule)` |
| One point in a group | `UNIQUE(id_setup_gateway_point_group, id_setup_gateway_device_point)` |
| One special day in a group | `UNIQUE(id_setup_gateway_point_group, id_setup_gateway_special_day)` |

Create/mutation `409`s correspond to a collision of these rules, an ambiguous
singular selector, or an incompatible relationship. A collection GET lists
every row and does not use `409` to express multiplicity.

## Relationships and content rules

```text
gateway setup
├── setup_gateway_config (1)
├── components (N)
│   ├── schedules (N)
│   ├── special_days (N)
│   ├── extensions (N) ── extension_schedules ── schedules
│   └── device_configs (N) per child setup
│       ├── device_points (N)
│       └── point_groups (N)
│           ├── point_group_points ── device_points
│           └── point_group_special_days ── special_days
```

- A schedule can be created without assigning it to a group. It is valid as a
  canonical row, but stays `on_hold` until the relationship that enables
  dispatch exists.
- `everyday` and `special_day` are scopes of `setup_gateway_schedules`. An
  everyday schedule is used for the group’s usual configuration and for
  extensions; an extension cannot point at a `special_day` schedule.
- Schedules belong to the component; point groups belong to the device
  config. The API validates that the group and schedule are compatible and
  that the schedule belongs to the same component.
- Point-group membership rules are evaluated per model point: at most one
  `everyday` group, multiple `special_day` groups for different day groups, and
  a special-day membership only after an everyday membership. Groups without a
  schedule are allowed as `unscheduled`; names do not pair or influence these
  rules.
- The importer is the reverse path: it receives an effective JSON snapshot,
  reconciles gateway MGD rows by upserting present rows and deleting absent
  rows, and records every effective write as `applied`. It is not a proposal
  source.
- The read projection currently serializes device-level `special_days` as a
  dictionary keyed by the reusable day-group name. This is separate from the
  importer input contract: importer input accepts only the v4.3 list of
  objects, while component-level reusable `special_days` remains a mapping.
  The database schema is unchanged.

The per-device `special_days` shape in the v4.3 gateway JSON is a list of
objects, each carrying `day_groups` and its `config_x_relay` overrides. The
importer does not accept the former dictionary keyed by arbitrary names: a
strict import returns `400`, while a non-strict import skips the invalid
section and reports `special_days_invalid_format`. Component-level
`special_days` remains the mapping that names reusable catalog rows.

## Persistence, promotion, and SQS

`before_value` and `after_value` are sparse patches: they contain only keys
that actually changed, except a delete that stores the domain snapshot. An
absent key means “do not touch”; a present key with `null` means “clear”. The
entity table reflects the new value from the mutation; `applied` only confirms
that it still matches.

The database requires `id_setup_target NOT NULL` and `id_resource NOT NULL`.
It does not use `resource_key` or a dependency table. It does not need an
outbox. When a group becomes `pending`, AP-v4 commits and sends the aggregate
event directly to SQS. If send fails,
`POST /mgd/setups/{id_setup}/config-changes/replay` republishes it without
changing status. The send response keeps `request_id` and `message_id`.

Endpoints outside `/mgd/*` do not use this state machine or this log.

`400` is an invalid projection or request, `404` is an out-of-scope gateway,
and `409` is a deterministic relationship conflict. An unexpected `500` is an
implementation defect.
